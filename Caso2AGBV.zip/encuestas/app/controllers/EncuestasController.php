<?php
require_once __DIR__ . '/../models/Encuesta.php';

class EncuestasController {
//Encuestas----------------------------------------------
    public function tituloEncuesta() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $titulo = $_POST['titulo'] ?? '';
        $id_creador = $_SESSION['user_id'] ?? null;
        if ($titulo && $id_creador) {
            $encuesta = new Encuesta();
            $encuesta->titulo($id_creador, $titulo);
            header('Location: /encuestas/auth/newEncuesta.php');
            exit();
        } else {
            $error = "El titulo esta vacio.";
            require_once __DIR__ . 'app/views/auth/newEncuesta.php';
        }
    } else {
            require_once __DIR__ . '/../views/auth/newEncuesta.php';
        }
    }
    public function descripcionEncuesta() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $descripcion = $_POST['descripcion'] ?? '';
        $id_creador = $_SESSION['user_id'] ?? null;
        if ($titulo && $id_creador) {
            $encuesta = new Encuesta();
            $encuesta->descripcion($id_creador, $descripcion);
            header('Location: /encuestas/auth/newEncuesta.php');
            exit();
        } else {
            $error = "falta descripcion";
            require_once __DIR__ . 'app/views/auth/newEncuesta.php';
        }
    } else {
            require_once __DIR__ . '/../views/auth/newEncuesta.php';
    }
}
public function agregarPregunta() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_encuesta = $_POST['id_encuesta'] ?? null;
            $texto = $_POST['texto'] ?? '';

            if ($id_encuesta && $texto) {
                $pregunta = new Pregunta();
                $pregunta->crear($id_encuesta, $texto);
                header('Location: /encuestas/encuestas/index');
                exit();
            } else {
                echo "Falta llenar las preguntas";
            }
        }
    }
    public function guardarEncuesta() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $titulo = $_POST['titulo'] ?? '';
        $descripcion = $_POST['descripcion'] ?? '';
        $preguntas = $_POST['preguntas'] ?? [];
        $id_creador = $_SESSION['user_id'] ?? null;

        if ($titulo && $descripcion && !empty($preguntas)) {
            $encuesta = new Encuesta();
            $id_encuesta = $encuesta->guardar($id_creador, $titulo, $descripcion);
            header('Location: /encuestas/auth/newEncuesta.php');
            exit();
        } else {
            $error = "Algo esta vacio";
            require_once __DIR__ . 'app/views/auth/newEncuesta.php';
        }
    } else {
            require_once __DIR__ . '/../views/auth/newEncuesta.php';
        }
}
//Listas----------------------------------------------
    public function listarEncuestas() {
    $encuesta = new Encuesta();
    $id_creador = $_SESSION['user_id'] ?? null;
    if ($id_creador) {
        return $encuesta->EncuestasdeUsuario($id_creador);
    }
    return [];
}

    public function listarPreguntas($id_encuesta = null) {
        $pregunta = new Pregunta();
        return $pregunta->listar($id_encuesta);
    }

    public function listarDisponibles() {
    $encuesta = new Encuesta();
    $id_usuario = $_SESSION['user_id'] ?? null;
    if ($id_usuario) {
        return $encuesta->listardisponibles($id_usuario);
    }
    return [];
}
}
