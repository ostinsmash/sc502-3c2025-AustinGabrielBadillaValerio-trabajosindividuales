<?php include 'app/views/layouts/header.php'; ?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">Opciones</div>
                <div class="card-body">
                    <a href="/encuestas/auth/newEncuesta" class="btn btn-success mb-3">Nueva Encuesta</a>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header bg-success text-white">Mis encuestas creadas</div>
                <div class="card-body">
            <?php if (!empty($encuestasCreadas)): ?>
                <ul>
            <?php foreach ($encuestasCreadas as $e): ?>
                <li><?= htmlspecialchars($e['titulo']) ?></li>
            <?php endforeach; ?>
        </ul>
            <?php else: ?>
            <p>Sin encuestas.</p>
        <?php endif; ?>
    </div>
            </div>
            <div class="card">
                <div class="card-header bg-info text-white">Encuestas disponibles por responder</div>
                <div class="card-body">
            <?php if (!empty($encuestasDisponibles)): ?>
                <ul>
            <?php foreach ($encuestasDisponibles as $e): ?>
                <li><?= htmlspecialchars($e['titulo']) ?></li>
            <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No hay nada por responder.</p>
        <?php endif; ?>
    </div>
            </div>
        </div>
    </div>
</div>

<?php include 'app/views/layouts/footer.php'; ?>