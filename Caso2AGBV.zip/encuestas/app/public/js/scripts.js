const usuario = {
  id: document.getElementById("usuarios_id"),
  nombre: document.getElementById("usuarios_nombre"),
  email: document.getElementById("usuarios_email"),
  password: document.getElementById("usuarios_password"),
  created_at: document.getElementById("usuarios_created_at")
};
const encuesta = {
  id: document.getElementById("encuestas_id"),
  id_creador: document.getElementById("encuestas_id_creador"),
  titulo: document.getElementById("encuestas_titulo"),
  descripcion: document.getElementById("encuestas_descripcion"),
  created_at: document.getElementById("encuestas_created_at")
};
const preguntas = {
  id: document.getElementById("preguntas_id"),
  id_creador: document.getElementById("preguntas_id_creador"),
  titulo: document.getElementById("preguntas_titulo"),
  descripcion: document.getElementById("preguntas_descripcion"),
  created_at: document.getElementById("preguntas_created_at")
};
const respuestas = {
  id: document.getElementById("respuestas_id"),
  id_creador: document.getElementById("respuestas_id_creador"),
  titulo: document.getElementById("respuestas_titulo"),
  descripcion: document.getElementById("respuestas_descripcion"),
  created_at: document.getElementById("respuestas_created_at")
};
const participantes = {
  id: document.getElementById("participantes_id"),
  id_creador: document.getElementById("participantes_id_creador"),
  titulo: document.getElementById("participantes_titulo"),
  descripcion: document.getElementById("participantes_descripcion"),
  created_at: document.getElementById("participantes_created_at")
};
//--------------------------------------------------------------------------
function getValues(obj) {
  const data = {};
  for (const key in obj) {
    if (obj[key]) data[key] = obj[key].value; 
  }
  return data;
}
//--------------------------------------------------------------------------
async function guardarUsuario() {
  const data = getValues(usuario);
  try {
    const response = await fetch("/api/usuarios.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    console.log("Usuario guardado:", result);
  } catch (error) {
    console.error("Error al guardar usuario:", error);
  }
}
//--------------------------------------------------------------------------
async function guardarEncuesta() {
  const data = getValues(encuesta);
  try {
    const response = await fetch("/api/encuestas.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    console.log("Encuesta guardada:", result);
  } catch (error) {
    console.error("Error al guardar encuesta:", error);
  }
}
//--------------------------------------------------------------------------
async function guardarPregunta() {
  const data = getValues(Pregunta);
  try {
    const response = await fetch("/api/encuestas.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    console.log("Pregunta guardada:", result);
  } catch (error) {
    console.error("Error al guardar pregunta:", error);
  }
}
//--------------------------------------------------------------------------

//--------------------------------------------------------------------------

//--------------------------------------------------------------------------

//--------------------------------------------------------------------------

//--------------------------------------------------------------------------