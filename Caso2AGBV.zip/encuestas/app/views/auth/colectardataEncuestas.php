<?php include 'app/views/layouts/header.php'; ?>
<div class="container mt-5">
    <div class="card p-4 mb-4" style="background-color: #f8f9fa;">
        <div class="mb-4">
            <button class="btn btn-danger">Eliminar Encuesta</button>
        </div>
        <?php 
        $preguntas = [
            ['nombre' => 'Pregunta 1', 'total' => 3, 'max' => 5],
            ['nombre' => 'Pregunta 2', 'total' => 4, 'max' => 5],
            ['nombre' => 'Pregunta 3', 'total' => 2, 'max' => 5],
        ];
        foreach ($preguntas as $p): 
            $porcentaje = ($p['total'] / $p['max']) * 100;
        ?>
        <div class="mb-3">
            <small><?= htmlspecialchars($p['nombre']) ?></small>
            <div class="d-flex justify-content-between align-items-center mt-1">
                <span>Total: <?= $p['total'] ?>/<?= $p['max'] ?></span>
                <div class="progress flex-grow-1 ms-2" style="height: 20px;">
                    <div class="progress-bar" role="progressbar" style="width: <?= $porcentaje ?>%;" aria-valuenow="<?= $p['total'] ?>" aria-valuemin="0" aria-valuemax="<?= $p['max'] ?>"></div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include 'app/views/layouts/footer.php'; ?>