<?php include 'app/views/layouts/header.php'; ?>
<h1>Crear Nueva Encuesta</h1>
<form>
    <div class="form-group mb-3">
        <label for="titulo">Título de la Encuesta</label>
        <input type="text" id="titulo" name="titulo" class="form-control" placeholder="Escribe el título" required>
        <form action="/encuestas/encuestas/tituloEncuesta" method="POST">
    </div>
    <div class="form-group mb-3">
        <label for="descripcion">Descripción</label>
        <textarea id="descripcion" name="descripcion" class="form-control" placeholder="Escribe la descripción" required></textarea>
    </div>
    <h3>Preguntas</h3>
    <div id="preguntas-container">
        <div class="form-group mb-2">
            <label>Pregunta 1</label>
            <input type="text" name="preguntas[]" class="form-control" placeholder="Escribe la pregunta 1" required>
        </div>
        <div class="form-group mb-2">
            <label>Pregunta 2</label>
            <input type="text" name="preguntas[]" class="form-control" placeholder="Escribe la pregunta 2" required>
        </div>
    </div>
    <div class="d-flex gap-2 mt-3">
        <button type="button" class="btn btn-secondary">+ Agregar Pregunta</button>
        <button type="submit" class="btn btn-primary">Guardar Encuesta</button>
    </div>
</form>
<?php include 'app/views/layouts/footer.php'; ?>