<?php include 'app/views/layouts/header.php'; ?>
<div class="container mt-5">
    <div class="card p-4" style="background-color: white;">
        <div class="mb-4">
            <label for="nombrePrincipal" class="form-label">Nombre Principal</label>
            <input type="text" id="nombrePrincipal" class="form-control" value="Nombre Prestado">
        </div>
        <?php 
        $nombresSecundarios = ['XXX', 'Nombre 1', 'Nombre 2', 'Nombre 3'];
        foreach ($nombresSecundarios as $index => $nombre): 
        ?>
        <div class="mb-3">
            <small><?= htmlspecialchars($nombre) ?></small>
            <div class="d-flex gap-2 mt-1">
                <?php for ($i = 1; $i <= 5; $i++): ?>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="respuesta_<?= $index ?>" id="respuesta_<?= $index ?>_<?= $i ?>" value="<?= $i ?>">
                    <label class="form-check-label" for="respuesta_<?= $index ?>_<?= $i ?>"><?= $i ?></label>
                </div>
                <?php endfor; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include 'app/views/layouts/footer.php'; ?>