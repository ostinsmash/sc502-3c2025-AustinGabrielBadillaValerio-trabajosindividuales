<a href="/auth/login" class="btn btn-primary mb-3">Go to Login</a>

<?php if (!empty($encuestas)): ?>
    <ul>
        <?php foreach ($encuestas as $e): ?>
            <li><?= htmlspecialchars($e['titulo']) ?> - <?= htmlspecialchars($e['descripcion']) ?></li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>oh</p>
<?php endif; ?>